# External evaluation inputs

Use a genuinely separate image collection or dataset with documented provenance. Freeze prompts, code, label mapping, and selection rules before viewing its test outcomes. Re-splitting RealWaste or TrashNet is not external validation.

The current runner accepts the same complete canonical label inventory as the source dataset. Images may use different original folders, because the manifest supplies the canonical labels. A dataset with a different taxonomy requires a defensible mapping fixed before evaluation; do not force unrelated classes into these labels.

Complete one external manifest with columns path,label,source_id,group_id. Paths are absolute or relative to the manifest's folder. source_id records collection provenance; group_id identifies the same object or scene when relevant. Keep actual image files available to the notebook. The blank manifests intentionally contain no invented image paths or labels.

Canonical RealWaste labels: cardboard; food organics; glass; metal; miscellaneous trash; paper; plastic; textile trash; vegetation.
Canonical TrashNet labels: cardboard; glass; metal; paper; plastic; trash.

Run the global image audit with the external manifest before evaluation. The budget runner rejects exact-file overlap with source images and duplicate external files. Identical-pixel/different-encoding matches and perceptual candidates require the image audit and human review. Collection provenance is still needed to establish independence.

Each external test uses source-budget-selected configurations and source support images unchanged. External labels are used only for reporting final metrics, not for tuning. Target-domain selection or adaptation using external labels would be a different experiment and must be budgeted and labeled separately.
