# Instructions for independent description authors

Give one CSV to each of three people. They should work separately and should not see model scores, winning prompts, test images, or each other's wording. The forms use anonymous author IDs; retain the actual identities, dates and authorship/consent records separately. The descriptions must actually be written by those people. Do not fill these forms with generated text and report it as independent human authorship.

For every category, supply three short English noun phrases in each family. Keep the category and family fields unchanged.

- name_preserving: retain the category name and add only light context; avoid naming a particular object subtype.
- material_framing: describe observable physical properties of the material; avoid object exemplars.
- object_expressions: give concrete objects or object groups associated with the category; avoid claims that they cover every member.

Write phrases that fit all three shared templates: “a photo of …”, “an image of …”, and “a close-up of …”. Do not write the template itself. Record any category that is difficult to describe, especially miscellaneous trash. Do not revise descriptions after looking at test results.

Return the completed CSVs. The builder checks completeness and applies the same templates to every family. It cannot verify who authored the descriptions or whether the people worked independently.

From the reproduction package root:

```bash
python scripts/build_independent_prompts.py --form research_inputs/author_1_descriptions.csv research_inputs/author_2_descriptions.csv research_inputs/author_3_descriptions.csv --out independent_prompts_v1
```

This produces separate RealWaste and TrashNet prompt CSVs. Select them in the budget notebook, use a new study name and feature folder, and report this as a separate prompt-author study. Each family/author/class configuration contains nine prompts: three authored descriptions crossed with the same three templates. Historical configurations contain three prompts; do not pool author studies with the historical grid without explicitly modeling this change.
